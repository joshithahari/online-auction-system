<?php
include "conn.php";
session_start();

// Handle logout before any output
if (isset($_POST['logoutbtn'])) {
  session_unset();
  session_destroy();
  header("Location: index.php");
  exit();
}

// Redirect if not logged in
if (!isset($_SESSION['setted']) || $_SESSION['setted'] != 1) {
  header("Location: Login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Art and Collectibles - Outbid Shop</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <style>
    body {
      font-family: 'Georgia', serif;
      background-color: #f7e4c6;
      margin: 20px;
      padding: 40px;
      text-align: center;
    }

    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #d8a06a;
    }

    .top-bar button {
      background-color: #d8a06a;
      border: none;
      padding: 10px 25px;
      font-size: 18px;
      border-radius: 8px;
      cursor: pointer;
    }

    .top-bar .logo {
      background-color: #d8a06a;
      padding: 15px 30px;
      font-size: 24px;
      border-radius: 10px;
      font-weight: bold;
    }

    .search-bar {
      margin: 30px auto;
      width: 60%;
      display: flex;
      align-items: center;
      border: 3px solid black;
      border-radius: 30px;
      overflow: hidden;
      background-color: white;
    }

    .search-bar input {
      width: 100%;
      border: none;
      padding: 15px;
      font-size: 18px;
      outline: none;
    }

    .search-bar span {
      padding: 0 15px;
      font-size: 22px;
    }

    h2 {
      margin-top: 20px;
      font-size: 32px;
    }

    .items-grid {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin-top: 30px;
    }

    .item {
      width: 220px;
      background: white;
      border-radius: 12px;
      padding: 15px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      text-align: left;
      cursor: pointer;
    }

    .item img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 8px;
    }

    .item h4 {
      margin: 10px 0 5px;
      font-size: 18px;
    }

    .item p {
      margin: 0;
      color: #555;
    }
  </style>
</head>

<body>


<!-- order placed Modal -->
<div class="modal fade" id="orderplacedModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel2">Order Placed</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
          <h5>Order Placed Successfully and will be delivered to your default location</h5>
      </div>
      
    </div>
  </div>
</div>



<!-- order  Modal -->
<div class="modal fade" id="buyModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <div class="mboxescover">
          <div class="imgbox text-center">
              <img src="" id="mimg" width="70%">
          </div>
          

          <div class="container">
            <div class="row mt-4">
              <div class="col">Item Condition <span id="mic"></span></div>
              <div class="col">Rs: <span id="mrs"></span></div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" id="buyit" data-bs-toggle='modal' data-bs-target='#orderplacedModal'>Buy</button>
      </div>
    </div>
  </div>
</div>







  <div class="top-bar">
    <a href="profile.php"><button>Profile</button></a>
    <div class="logo">🏷️ outbid <br><small>one click to own it!</small></div>
    <button>Buying</button>
  </div>

  <div class="search-bar">
    <span>🔍</span>
    <input type="text" placeholder="search for anything" id="serachit" />
  </div>
  <h2>shop now!</h2>



  <div class="items-grid" id="itembox">
    <?php
    $sql = "SELECT * FROM `items` WHERE `item_cat`='Art and Collectibles'";
    $res = mysqli_query($conn, $sql);

    if (mysqli_num_rows($res) > 0) {
      while ($nrow = mysqli_fetch_assoc($res)) {
        $sno = $nrow['sno'];
        $item_condition = $nrow['item_condition'];
        $item_name = $nrow['item_name'];
        $fixed_price = $nrow['fixed_price'];
        $picture = $nrow['picture'];

        echo "
        
          <div class='item' data-bs-toggle='modal' data-bs-target='#buyModal'>
            <img src='{$picture}' >
            <h4>{$item_name}</h4>
            <p>{$fixed_price}</p>
            <p>{$item_condition}</p>
          </div>
        ";
      }
    }
    ?>
  </div>




  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.js"></script>
  <script>
    $("#serachit").keyup(function() {
      var getsearch = $(this).val();
      var getcat = "Art and Collectibles";

      $.ajax({
        type: "post",
        url: "search_box_php.php",
        data: {
          getsearch: getsearch,
          getcat: getcat
        },
        success: function(response) {
          $("#itembox").empty();
          $("#itembox").append(response);
        }
      })

    })


    
    $("#buyit").click(function(){
        $("#buyModal").modal("toggle");
      
    })

   


    $(document).on("click", ".item", function() {
      var itemname = $($(this).children()[1]).text();
      var itemprice = $($(this).children()[2]).text();
      var itemcondition = $($(this).children()[3]).text();

      var itemimage = $($(this).children()[0]).attr("src");


      $("#exampleModalLabel").text(itemname);
      $("#mimg").attr("src", itemimage);
      $("#mic").text(itemcondition);
      $("#mrs").text(itemprice);

    })
  </script>


</body>

</html>