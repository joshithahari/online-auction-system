<?php
    include "conn.php";
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body{
            background-image: url("images/plainpage.jpg"); 
            height: 100vh;
            width: 100%;
            background-size: cover;
            background-position: center;
        }

        .logo-box {
            text-align: center;
            padding: 40px 20px 20px;
        }
        .logo-box .logo {
            display: inline-block;
            background-color: #dba76b;
            border: 4px solid #000;
            padding: 20px 150px;
            font-size: 36px;
            font-weight: bold;
            border-radius: 12px;
        }

        .logo-box .tagline {
            font-size: 16px;
            margin-top: 5px;
            font-style: italic;
        }

        #i1{
            margin-top: 100px;
        }

        .c1{
            background-color: bisque;
            padding: 10px;
            font-size: 20px;
        }
        #main{
            width: 500px;
            margin: 100px auto 0px auto;
        }
        #loginbtn{
            background-color: chocolate;
            padding: 5px 40px;
            margin-top: 40px;
            float: right;
            font-size: 30px;
        }
       
    </style>
</head>
<body>
    <center>
        
    </center>
    <div class="logo-box">
        <div class="logo">
          <img src="https://cdn-icons-png.flaticon.com/512/833/833314.png" alt="Tag" style="width:30px; vertical-align: middle; margin-right: 10px;">
          outbid
          <div class="tagline">one click to ,own it!</div>
        </div>
      </div>
    
    
    <form action="Login.php" method="post" id="main">

        <div class="mt-2">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" placeholder="Enter my Username" class="form-control c1">
        </div>
        <div class="mt-4">
            <label for="pass">Password</label>
            <input type="password" id="pass" name="pass" placeholder="Enter password" class="form-control c1">
        </div>

        <a href="Login.html">
            <input type="submit" value="login" id="loginbtn" name="loginbtn" class="btn ">
        </a>

        <center>
            <?php
                if( isset( $_POST['loginbtn'] )  ){
                    $username=$_POST['username'];
                    $pass=$_POST['pass'];

                    if($username!=""  && $pass!=""){

                        $sql="SELECT * FROM `users` WHERE `username`='$username' AND `password`='$pass'";
                        $res=mysqli_query($conn,$sql);

                        if(mysqli_num_rows($res)>0){
                            $_SESSION['setted']=1;
                            header("location:  afterloginpage.php");
                        }else{
                            echo "Wrong Credentials";
                        }



                    }else{
                        echo "Username and password cannot be blank";
                    }
                }
            ?>
        </center>

    </form>


   


    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script>

    </script>
</body>
</html>