<?php
  include "conn.php";
  session_start();

  // Handle logout before any output
  if (isset($_POST['logoutbtn'])) {
      session_unset();
      session_destroy();
      header("Location: index.php");
      exit();
  }

  // Redirect if not logged in
  if (!isset($_SESSION['setted']) || $_SESSION['setted'] != 1) {
      header("Location: Login.php");
      exit();
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Selling Page</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {
      font-family: 'Georgia', serif;
      background-color: #f7e4c6;
      margin: 0;
      padding: 0;
    }

    .main-layout {
      display: flex;
      min-height: 100vh;
    }

    .sidebar {
      width: 200px;
      /* background-color: #ffe0b2; */
      padding: 20px;
      /* box-shadow: 2px 0 5px rgba(0,0,0,0.1); */
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
    }
    

   

    .sidebar a {
      display: block;
      margin: 20px 0;
      text-decoration: none;
      font-size: 18px;
      font-weight: bold;
      color: #333;
      background-color: #d8a06a;
      padding: 10px 20px;
      border-radius: 8px;
      text-align: center;
      width: 100%;
    }

    .content {
      flex-grow: 1;
      padding: 40px;
      text-align: center;
    }

    .header {
      font-size: 40px;
      font-weight: bold;
      margin-bottom: 20px;
      padding: 10px;
      border: 3px solid black;
      display: inline-block;
      position: relative;
    }

    .header::before {
      content: '🏷️';
      position: absolute;
      left: -40px;
      top: 50%;
      transform: translateY(-50%);
      font-size: 30px;
    }

    .search-container {
      margin: 20px 0 40px;
      display: flex;
      justify-content: center;
      gap: 10px;
    }

    .search-input {
      padding: 10px 15px;
      width: 300px;
      border-radius: 8px;
      border: 2px solid #ccc;
      font-size: 16px;
    }

    .search-button {
      padding: 10px 20px;
      background-color: #d8a06a;
      border: none;
      border-radius: 8px;
      font-weight: bold;
      font-size: 16px;
      cursor: pointer;
    }

    .search-button:hover {
      background-color: #bb7f45;
    }

    .container {
      display: flex;
      justify-content: center;
      gap: 60px;
      margin-top: 30px;
    }

    .card {
      width: 400px;
      background-color: #fffaf2;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .button-label {
      background-color: #d8a06a;
      color: black;
      border: none;
      padding: 10px 30px;
      font-size: 22px;
      font-weight: bold;
      border-radius: 10px;
      cursor: pointer;
      margin-bottom: 15px;
    }

    .button-label:hover {
      background-color: #bb7f45;
    }

    .card p {
      margin: 15px 0;
      font-size: 16px;
    }

    .card img {
      width: 100%;
      height: auto;
      border-radius: 8px;
    }

    .card a {
      display: block;
      margin-top: 20px;
      font-size: 18px;
      color: #000;
      text-decoration: none;
      font-weight: bold;
    }

    .card a:hover {
      text-decoration: underline;
    }

    .lout {
      background-color: #d8a06a;
    }

    #c1{
      background-image: linear-gradient(to bottom, rgba(184, 184, 184, 0.753),rgba(255, 255, 255, 0.737)),url("images/b.jpg");
      background-size: cover;
    }
     #c2{
      background-image: linear-gradient(to bottom, rgba(184, 184, 184, 0.797),rgba(255, 255, 255, 0.77)),url("images/bb.jpeg");
      background-size: cover;
    }
  </style>
</head>
<body>
  <div class="main-layout">

    <!-- Left Sidebar: Profile -->
    <div class="sidebar">
      <a href="profile.php">👤 Profile</a>
    </div>

    <!-- Main Content -->
    <div class="content">
      <div class="header">Selling</div>

      <!-- Search Bar -->
      <div class="search-container">
        <input type="text" class="search-input" placeholder="Search items or categories...">
        <button class="search-button">Search</button>
      </div>

      <!-- Selling and Auction Cards -->
      <div class="container">
        <div class="card" id="c1">
          <a href="selling3.php"><button class="button-label">sell</button></a>
          <p>You can list new or used items and pay a final value fee only when it sells.</p>
          <img src="https://via.placeholder.com/350x200.png?text=Online+Store" alt="Sell Example" />
          <a href="selling3.php">want to sell an item? click here!</a>
        </div>

        <div class="card" id="c2">
          <a href="buyer.php"><button class="button-label">buyer</button></a>
          <p>Offer a particular amount of money for something that is for sale and compete against other people to buy it.</p>
          <img src="https://via.placeholder.com/350x200.png?text=Auction+Crowd" alt="Auction Example" />
          <a href="buyer.php">want to auction an item? click here!</a>
        </div>
      </div>
    </div>

    <!-- Right Sidebar: About Us -->
    <div class="sidebar">
      <a href="about.php">ℹ️ About Us</a>

      <!-- Logout form -->
      <form action="afterloginpage.php" method="post">
          <input type="submit" name="logoutbtn" value="Logout" class="btn px-5 lout">
      </form>
    </div>
  </div>

  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
