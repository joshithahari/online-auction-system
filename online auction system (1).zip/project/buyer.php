<?php
include "conn.php";
session_start();

// Handle logout before any output
if (isset($_POST['logoutbtn'])) {
  session_unset();
  session_destroy();
  header("Location: index.php");
  exit();
}

// Redirect if not logged in
if (!isset($_SESSION['setted']) || $_SESSION['setted'] != 1) {
  header("Location: Login.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
  <style>
    body {
      font-family: 'Georgia', serif;
      background-color: #f7e4c6;
      margin: 0;
      padding: 30px;
      text-align: center;
    }
    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .top-bar button {
      background-color: #d8a06a;
      border: none;
      padding: 10px 25px;
      font-size: 18px;
      border-radius: 8px;
      cursor: pointer;
    }

    .top-bar .logo {

      background-color: #d8a06a;
      padding: 15px 30px;
      font-size: 24px;
      border-radius: 10px;
      font-weight: bold;
    }
     .sidebar {
      width: 200px;
      background-color: #ffe0b2;
      padding: 20px;
      box-shadow: 2px 0 5px rgba(0,0,0,0.1);
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
    }

    .sidebar a {
      display: block;
      margin: 20px 0;
      text-decoration: none;
      font-size: 18px;
      font-weight: bold;
      color: #333;
      background-color: #bb7f45;
      padding: 10px 20px;
      border-radius: 8px;
      text-align: center;
      width: 100%;
    }

    .search-bar {
      margin: 30px auto;
      width: 60%;
      display: flex;
      align-items: center;
      border: 3px solid black;
      border-radius: 30px;
      overflow: hidden;
      background-color: white;
    }

    .search-bar input {
      width: 100%;
      border: none;
      padding: 15px;
      font-size: 18px;
      outline: none;
    }

    .search-bar span {
      padding: 0 15px;
      font-size: 22px;
    }

    h2 {
      margin-top: 20px;
      font-size: 32px;
    }

    .grid {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      margin-top: 30px;
      gap: 40px;
    }

    .category {
      width: 250px;
      cursor: pointer;
      text-decoration: none;
      color: black;
    }

    .category img {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .category p {
      font-size: 20px;
      margin-top: 10px;
    }

    #klulogo {
      height: 50px;
      width: auto;
      margin-left: 15px;
    }
  </style>
</head>

<body>
  
  <div class="top-bar">
    <a href="profile.php">
       <button>👤Profile</button>
    </a>
    <div class="logo"> OUTBIT <br><small>one click to own it!</small>
      <img src="images/klu.jpeg" id=klulogo alt="KL university logo">
    </div>
    <button>Logout</button>
  </div>

  <div class="search-bar">
    <span>🔍</span>
    <input type="text" placeholder="search for anything" />
  </div>

  <h2>shop now!</h2>

  <div class="grid">
    <a href="buyerelecttonies.php" class="category">
      <img src="images/electronics.jpeg" alt="">
      <img src="https://via.placeholder.com/250x180.png?text=Electronics" alt="Electronics">

    </a>

    <a href="fashion.php" class="category">
      <img src="images/faction.jpeg" alt="">
      <img src="https://via.placeholder.com/250x180.png?text=Fashion" alt="Fashion">

    </a>

    <a href="ArtandCollectibles.php" class="category">
      <img src="images/arts.jpeg" alt="" srcset="">
      <img src="https://via.placeholder.com/250x180.png?text=Art+and+Collectibles" alt="ArtandCollectibles">

    </a>

    <a href="Automobiles.php" class="category">
      <img src="images/automabiles.jpeg" alt="" srcset="">
      <img src="https://via.placeholder.com/250x180.png?text=Automobile" alt="Automobile">

    </a>

    <a href="Homeaccessories.php" class="category">
      <img src="images/home accessories.jpeg" alt="" srcset="">
      <img src="https://via.placeholder.com/250x180.png?text=Automobile" alt="Home accessories">

    </a>


  </div>
</body>

</html>