<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Electronics - Outbid Shop</title>
  <style>
    body {
      font-family: 'Georgia', serif;
      background-color: #f7e4c6;
      margin: 0;
      padding: 30px;
      text-align: center;
    }

    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .top-bar .logo {
      background-color: #d8a06a;
      padding: 15px 30px;
      font-size: 24px;
      border-radius: 10px;
      font-weight: bold;
    }

    h2 {
      margin-top: 20px;
      font-size: 32px;
    }

    .items-grid {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin-top: 30px;
    }

    .item {
      width: 220px;
      background: white;
      border-radius: 12px;
      padding: 15px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      text-align: left;
      cursor: pointer;
    }

    .item img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 8px;
    }

    .item h4 {
      margin: 10px 0 5px;
      font-size: 18px;
    }

    .item p {
      margin: 0;
      color: #555;
    }

    .details {
      margin-top: 40px;
      background: #fff;
      padding: 25px;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      display: none;
      max-width: 400px;
      margin-left: auto;
      margin-right: auto;
      text-align: left;
    }

    .details img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 10px;
    }

    .details h3 {
      margin-top: 15px;
    }

    .details p {
      margin: 5px 0;
    }

    .buy-btn {
      margin-top: 15px;
      background-color: #d8a06a;
      padding: 10px 25px;
      font-size: 18px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="top-bar">
    <div></div>
    <div class="logo">🏷️ outbid</div>
    <div></div>
  </div>

  <h2>Electronics</h2>

  <div class="items-grid" id="itemsGrid"></div>

  <div class="details" id="detailsBox">
    <img id="detailImage" src="" alt="Selected item">
    <h3 id="detailTitle"></h3>
    <p id="detailPrice"></p>
    <p id="detailDesc"></p>
    <button class="buy-btn" onclick="alert('Proceeding to buy...')">Buy Now</button>
  </div>

  <script>
    const items = [
      {
        title: "Smartphone",
        price: "$499",
        desc: "Latest 5G smartphone with AMOLED display.",
        img: "https://via.placeholder.com/220x150.png?text=Smartphone"
      },
      {
        title: "Tablet",
        price: "$299",
        desc: "Lightweight tablet perfect for media and browsing.",
        img: "https://via.placeholder.com/220x150.png?text=Tablet"
      },
      {
        title: "Laptop",
        price: "$899",
        desc: "High-performance laptop for work and gaming.",
        img: "https://via.placeholder.com/220x150.png?text=Laptop"
      },
      {
        title: "Smartwatch",
        price: "$199",
        desc: "Fitness and notification tracker with sleek design.",
        img: "https://via.placeholder.com/220x150.png?text=Smartwatch"
      }
    ];

    const itemsGrid = document.getElementById('itemsGrid');
    const detailBox = document.getElementById('detailsBox');
    const detailImage = document.getElementById('detailImage');
    const detailTitle = document.getElementById('detailTitle');
    const detailPrice = document.getElementById('detailPrice');
    const detailDesc = document.getElementById('detailDesc');

    items.forEach(item => {
      const itemDiv = document.createElement('div');
      itemDiv.className = 'item';
      itemDiv.innerHTML = `
        <img src="${item.img}" alt="${item.title}">
        <h4>${item.title}</h4>
        <p>${item.price}</p>
      `;
      itemDiv.addEventListener('click', () => {
        detailBox.style.display = 'block';
        detailImage.src = item.img;
        detailTitle.textContent = item.title;
        detailPrice.textContent = item.price;
        detailDesc.textContent = item.desc;
      });
      itemsGrid.appendChild(itemDiv);
    });
  </script>
</body>
</html>