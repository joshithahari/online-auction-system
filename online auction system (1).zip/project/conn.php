<?php
    $address="localhost";
    $user="root";
    $pass="";
    $db="outbid";

    $conn=mysqli_connect($address,$user, $pass, $db);

    if(!$conn){
        die("Failed to Connect");
    }
   

?>