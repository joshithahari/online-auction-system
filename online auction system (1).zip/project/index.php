<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {
      background-image: url("images/plainpage1.jpg");
      height: 100vh;
      width: 100%;
      background-size: cover;
      background-position: center;
    }

    #i1 {
      margin-top: 100px;
      height: 20vh;
    }

    #login,
    #signup {
      background-color: chocolate;
      padding: 25px 150px;
      margin-top: 50px;

    }

    .logo-box {
      text-align: center;
      padding: 40px 20px 20px;
    }

    .logo-box .logo {
      display: inline-block;
      background-color: #dba76b;
      border: 4px solid #000;
      padding: 20px 150px;
      font-size: 36px;
      font-weight: bold;
      border-radius: 12px;
    }

    .buttons {
      text-align: center;
      margin-top: 50px;
    }

    .logo-box .tagline {
      font-size: 16px;
      margin-top: 5px;
      font-style: italic;
    }
  </style>
</head>

<body>
  <div class="logo-box">
    <div class="logo">
      <img src="https://cdn-icons-png.flaticon.com/512/833/833314.png" alt="Tag" style="width:30px; vertical-align: middle; margin-right: 10px;">
      outbid
      <div class="tagline">one click to ,own it!</div>
    </div>
  </div>

  <center>
    <a href="Login.php">
      <input type="button" value="login" id="login" class="btn ">
    </a>
    <br>
    <a href="signup.php">
      <input type="button" value="Signup" id="signup" class="btn ">
    </a>
  </center>

  <a href="profile.php">
    <button class="button">👤 Profile</button>
  </a>

  <link rel="stylesheet" href="css/bootstrap.min.css">


  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script>

  </script>
</body>

</html>