<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Document</title>
  <style>
    body {
      font-family: 'Georgia', serif;
      background-color: #fef6e4;
      margin: 0;
      padding: 20px 40px;
      color: #000;
    }

    .header {
      display: flex;
      justify-content: center;
      margin-bottom: 100px;

    }

    .logo {
      background-color: #dba76b;
      padding: 20px 200px;
      border-radius: 10px;
      font-size: 28px;
      font-weight: bold;
      text-align: center;
      line-height: 1.2;
      border: 3px solid #000;
    }

    .main-content {
      display: flex;
      gap: 40px;
      align-items: flex-start;
    }

    .image-box {
      width: 250px;
      height: 250px;
      background-color: #fff;
      border: 5px solid #dba76b;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      text-align: center;
    }

    .info {
      flex-grow: 1;
      text-align: left;
    }

    .info p {
      margin: 10px 0;
      font-size: 18px;
    }

    .description {
      margin-top: 20px;
      font-style: italic;
      color: #333;
    }

    .confirmation {
      margin-top: 40px;
      background-color: #dba76b;
      padding: 20px;
      border-radius: 10px;
      font-size: 20px;
      text-align: center;
      max-width: 500px;
      margin-left: auto;
    }
  </style>
</head>
<body>

  <div class="header">
    <div class="logo">
      outbid<br>
      <small style="font-size: 14px; font-weight: normal;" >one click to own it!</small>
    </div>
  </div>

  <div class="main-content">
    <div class="image-box">
      picture of<br>uploaded item
    </div>

    <div class="info">
      <p><strong>Price of the item:</strong> ₹XXX</p>
      <p><strong>Condition:</strong> Pre-owned / New / Auction item</p>
      <div class="description">
        item description......
      </div>
    </div>
  </div>

  <div class="confirmation">
    dear user!!<br>
    your item is successfully<br>
    uploaded on outbid
  </div>

</body>
</html>
