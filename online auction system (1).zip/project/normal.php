<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Outbid - Welcome</title>
  <style>
    body {
      font-family: 'Georgia', serif;
      background-color: #fef6e4;
      margin: 0;
      padding: 0;
      overflow-x: hidden;
      position: relative;
    }

    .logo-box {
      text-align: center;
      padding: 40px 20px 20px;
    }

    .logo-box .logo {
      display: inline-block;
      background-color: #dba76b;
      border: 4px solid #000;
      padding: 20px 60px;
      font-size: 36px;
      font-weight: bold;
      border-radius: 12px;
    }

    .logo-box .tagline {
      font-size: 16px;
      margin-top: 5px;
      font-style: italic;
    }

    .buttons {
      text-align: center;
      margin-top: 50px;
    }

    .btn {
      background-color: #dba76b;
      border: none;
      padding: 15px 40px;
      margin: 15px;
      font-size: 20px;
      font-family: 'Georgia', serif;
      cursor: pointer;
      border-radius: 8px;
      width: 200px;
    }

    .decor {
      position: absolute;
      z-index: -1;
    }

    /* Decorative images around */
    .watch { top: 20px; left: 10px; width: 80px; }
    .lamp { top: 120px; left: 40px; width: 70px; }
    .camera { bottom: 130px; left: 30px; width: 80px; }
    .bag { bottom: 50px; left: 10px; width: 90px; }
    .iphone { top: 20px; right: 20px; width: 80px; }
    .laptop { top: 100px; right: 60px; width: 90px; }
    .painting { bottom: 130px; right: 50px; width: 90px; }
    .car { bottom: 30px; right: 10px; width: 100px; }
  </style>
</head>
<body>

  <!-- Logo Section -->
  <div class="logo-box">
    <div class="logo">
      <img src="https://cdn-icons-png.flaticon.com/512/833/833314.png" alt="Tag" style="width:30px; vertical-align: middle; margin-right: 10px;">
      outbid
      <div class="tagline">one click to ,own it!</div>
    </div>
  </div>

  <!-- Login/Signup Buttons -->
  <div class="buttons">
    <button class="btn">login</button><br>
    <button class="btn">sign up</button>
  </div>

  <!-- Decorative Images -->
  <img src="https://upload.wikimedia.org/wikipedia/commons/0/0a/Watch_(3615676575).jpg" class="decor watch">
  <img src="https://upload.wikimedia.org/wikipedia/commons/8/8b/Vintage_Lamp.png" class="decor lamp">
  <img src="https://upload.wikimedia.org/wikipedia/commons/6/66/Sony_DSC-P1.jpg" class="decor camera">
  <img src="https://upload.wikimedia.org/wikipedia/commons/3/36/Christian_Dior_Handbag.jpg" class="decor bag">
  <img src="https://upload.wikimedia.org/wikipedia/commons/1/1c/IPhone_13_Pink.svg" class="decor ipho
