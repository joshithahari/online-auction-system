<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Profile</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
   
    <style>
        body {
            background-color: #f5deb3;
            font-family: Arial, sans-serif;
            padding: 30px;
        }
        .profile-container {
            background-color: #fffaf0;
            padding: 20px;
            border-radius: 12px;
            max-width: 400px;
            margin: auto;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .profile-container h2 {
            text-align: center;
        }
        .profile-detail {
            margin: 10px 0;
        }
        .back-button {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }
        .back-button:hover {
            color: #b57f4f;
        }
    </style>
</head>
<body>

    <div class="profile-container">
        <h2>User Profile</h2>
        <hr>
        <div class="mt-2">
            <label for="name1">Name</label>
            <input type="text" class="form-control" name="name1" id="name1" >
        </div>
         <div class="mt-2">
            <label for="email1">Email</label>
            <input type="text" class="form-control" name="email1" id="email1" >
        </div>
        <div class="mt-2">
             <label for="joined1">Joined On</label>
            <input type="text" class="form-control" name="joined1" id="joined1" >
        </div>
        <div class="mt-3">
            <input type="submit" value="Change">
        </div>
      
        <a class="back-button" href="afterloginpage.php">← Back to Home</a>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>

</body>
</html>