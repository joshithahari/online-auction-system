<?php
    include "conn.php";
    session_start();
    
    $getsearch=$_POST['getsearch'];
    $getcat=$_POST['getcat'];


    $sql = "SELECT * FROM `items` WHERE `item_cat` = '$getcat' AND `item_name` LIKE '%$getsearch%'";
    $res = mysqli_query($conn, $sql);

    if (mysqli_num_rows($res) > 0) {
      while ($nrow = mysqli_fetch_assoc($res)) {
        $sno = $nrow['sno'];
        $item_condition = $nrow['item_condition'];
        $item_name = $nrow['item_name'];
        $fixed_price = $nrow['fixed_price'];
        $picture = $nrow['picture'];

        echo "
        
          <div class='item' data-bs-toggle='modal' data-bs-target='#buyModal'>
            <img src='{$picture}' >
            <h4>{$item_name}</h4>
            <p>{$fixed_price}</p>
            <p>{$item_condition}</p>
          </div>
        ";
      }
    }


?>