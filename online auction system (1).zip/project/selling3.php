<?php
  include "conn.php";
  session_start();

  // Handle logout before any output
  if (isset($_POST['logoutbtn'])) {
      session_unset();
      session_destroy();
      header("Location: index.php");
      exit();
  }

  // Redirect if not logged in
  if (!isset($_SESSION['setted']) || $_SESSION['setted'] != 1) {
      header("Location: Login.php");
      exit();
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sell an Item</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {
      background-image: url("images/plainpage1.jpg");
      height: 100vh;
      width: 100%;
      background-size: cover;
      background-position: center;
    }

    .sell-header {
      margin-top: 40px;
    }

    .sell-button {
      background-color: #d09b61;
      border: 3px solid black;
      padding: 15px 30px;
      font-size: 24px;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 10px;
    }

    .sell-button::before {
      content: "🏷️";
      font-size: 24px;
    }

    h2 {
      margin: 20px 0;
      font-size: 24px;
      color: #333;
    }

    .form-container {
      background-color: #d09b61;
      width: 420px;
      margin: 30px auto;
      padding: 20px;
      border-radius: 12px;
      text-align: left;
    }

    label {
      display: block;
      font-size: 18px;
      margin: 15px 0 5px;
      color: #fff;
    }

    input[type="text"],
    input[type="number"],
    input[type="file"] {
      width: 100%;
      padding: 5px;
      font-size: 16px;
      border: none;
      border-radius: 6px;
    }

    input[type="file"] {
      background-color: #fff;
    }

    .next-button {
      margin-top: 20px;
      background-color: #f0ece4;
      font-size: 18px;
      font-weight: bold;
      padding: 10px 20px;
      border-radius: 6px;
      border: 2px solid #444;
      cursor: pointer;
      width: 100%;
    }

    .next-button:hover {
      background-color: #e1d7c2;
    }
  </style>
</head>

<body>
  <center>
    <div class="sell-header">
      <button class="sell-button">Sell an item</button>
      <h2>Make money selling on outbid</h2>
    </div>
  </center>

  <form action="selling3.php" method="post" enctype="multipart/form-data">

    <div class="form-container">
      <label for="icon">Item Condition</label>
      <select name="icon" id="icon" class="form-select">
        <option value="0">Select Item Condition</option>
        <option value="New">New</option>
        <option value="Old">Old</option>
      </select>

      <label for="iname">Item Name</label>
      <input type="text" id="iname" name="iname" placeholder="Item Name">

      <label for="price">fix price</label>
      <input type="number" id="price" name="price" placeholder="$ add amount">

      <label for="icat">Item Category</label>
      <select name="icat" id="icat" class="form-select">
        <option value="0">Select Item Category</option>
        <option value="Electronics">Electronics</option>
        <option value="Fashion">Fashion</option>
        <option value="Art and Collectables">Art and Collectables</option>
        <option value="Automobiles">Automobiles</option>
        <option value="Home Accessories">Home Accessories</option>
      </select>

      <label for="image">upload picture</label>
      <input type="file" class="form-control" id="image" name="image" accept="image/*">

      <button type="submit" name="sellitbtn" class="next-button">Submit</button>


      <?php
      if (isset($_POST['sellitbtn'])) {
        $icon = $_POST['icon'];
        $iname = $_POST['iname'];
        $price = $_POST['price'];
        $icat = $_POST['icat'];


        if ($icon != 0 && $iname != "" && $price != "" && $icat != "") {
         $img_name = $_FILES['image']['name'];
           $img_tmp_name = $_FILES['image']['tmp_name'];
         $location = "item_images/" . $img_name;
          move_uploaded_file($img_tmp_name, $location);


          $sql="INSERT INTO `items`( `item_condition`, `item_name`, `fixed_price`, `item_cat`, `picture`) VALUES ('$icon','$iname','$price','$icat','$location')";
          $res=mysqli_query($conn,$sql);
          if($res){
            echo "{$iname} Uploaded Successfully <br> <img src='{$location}' height='200px'>";
          }else{
            echo "Failed to upload item";
          }



        }
        else{
          echo "please select and fill all fields";
        }
      }
      ?>
    </div>
  </form>

  <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>