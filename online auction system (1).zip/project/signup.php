<?php
    include "conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <style>
        body{
            background-image: url("images/plainpage.jpg");
            height: 100vh;
            width: 100%;
            background-size: cover;
            background-position: center;
        }
        .logo-box {
            text-align: center;
            padding: 40px 20px 20px;
        }
        .logo-box .logo {
            display: inline-block;
            background-color: #dba76b;
            border: 4px solid #000;
            padding: 20px 150px;
            font-size: 36px;
            font-weight: bold;
            border-radius: 12px;
        }

        .logo-box .tagline {
            font-size: 16px;
            margin-top: 5px;
            font-style: italic;
        }
        #i1{
            margin-top: 100px;
        }
        
        #main{
            width: 500px;
            margin: 100px auto 0px auto;
        }
        #Signupbtn{
            background-color: chocolate;
            padding: 5px 40px;
            margin-top: 50px;
            float: right;
            font-size: 30px;
        }
       
       
    </style>
</head>
<body>

    <div class="logo-box">
        <div class="logo">
          <img src="https://cdn-icons-png.flaticon.com/512/833/833314.png" alt="Tag" style="width:30px; vertical-align: middle; margin-right: 10px;">
          outbid
          <div class="tagline">one click to ,own it!</div>
        </div>
    </div>

    
    <form action="signup.php" method="post"  id="main">
          <div class="mt-0">
            <label for="nname">Name <span class="text-danger">*</span> </label>
            <input type="text" id="nname" name="nname" placeholder="Enter Name" class="form-control c1">
        </div>
        <div class="mt-2">
            <label for="username">Username <span class="text-danger">*</span> </label>
            <input type="text" id="username" name="username" placeholder="Enter Username" class="form-control c1">
        </div>
        <div class="mt-2">
            <label for="email">Email</label>
            <input type="text" id="email" name="email" placeholder="Enter my Email Id" class="form-control c1">
        </div>
        <div class="mt-4">
            <label for="pass">Password <span class="text-danger">*</span></label>
            <input type="password" id="pass" name="pass" placeholder="Enter Password" class="form-control c1">
        </div>
        
        
   
        <input type="submit" value="Signup" id="Signupbtn" name="Signupbtn" class="btn ">
   
          <center>
          <?php
        if( isset( $_POST["Signupbtn"] ) ){

            $username=$_POST['username'];
            $email=$_POST['email'];
            $pass=$_POST['pass'];
            $nname=$_POST['nname'];

            if($username !="" && $pass!=""){

                $sql="INSERT INTO `users`(  `name`, `username`, `password`, `email`) VALUES ('$nname','$username','$pass','$email')";
                $res=mysqli_query($conn,$sql);

                if($res){
                    echo "User Added You can Login Now: <a href='Login.php'>Click here to Login</a> ";
                }else{
                    echo "Failed to Add User";
                }



            }else{
                echo "<h6 class=' text-danger'> Username and password are Compulsory </h6>";
            }
            
        }
    ?>
    </center>
   
    </form>
      

   

  



    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script>

    </script>
</body>
</html>